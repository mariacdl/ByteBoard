#include "Tablero.h"

class Configuracion{
    public:
    //Genera un tablero según la modalidad ('P' o 'S')
    Tablero genTablero(char modalidad);
};